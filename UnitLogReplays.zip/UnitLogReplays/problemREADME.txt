My remaining issues:
1. I'm trying to use #include "json.hpp" to format it into a json
but I keep getting an error
2. I don't know how to switch the replay so it is on the "enemy" side
What my code currently does:
1. If you run replay.exe, in the cmd/terminal the there will be constant
output whenever a unit model is created
2. After a replay is done, a text file will be created in the
format of "Replay 'Replay_Num'UnitLog.txt" in your build\bin folder
3. "Replay 1UnitLog.txt" and "Replay 2UnitLog.txt" are the result of
running two replays with replay.exe
4. It should be noted that these txt's don't include the first 12 worker
units and the main building (Nexus, CC, Hatchery) that you start the game with.