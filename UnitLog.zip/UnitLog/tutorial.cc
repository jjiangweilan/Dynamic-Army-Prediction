#include <sc2api/sc2_api.h>

#include <iostream>

#include <fstream>

using namespace sc2;

class Bot : public Agent {
public:
	std::vector<uint32_t> unit_count;

    virtual void OnGameStart() final {
    	//https://github.com/Blizzard/s2client-api/blob/master/examples/replay.cc sample
    	const sc2::ObservationInterface* obs = Observation();
        assert(obs->GetUnitTypeData().size() > 0);
        unit_count.resize(obs->GetUnitTypeData().size());
        std::fill(unit_count.begin(), unit_count.end(), 0);
    	// Initializes Text file for Unit Composition
        std::ofstream myfile ("UnitLog.txt");
        myfile.close();
    }

    virtual void OnStep() final {
        std::cout << Observation()->GetGameLoop() << std::endl;
    }

    virtual void OnUnitCreated(const sc2::Unit* unit) final {
    	// based on https://github.com/Blizzard/s2client-api/blob/master/examples/replay.cc
    	//counts the unit type
    	++unit_count[unit->unit_type];
    	std::ofstream myfile;
    	//stores the unit types into the log
    	myfile.open ("UnitLog.txt", std::ios::app);

    	//gets unit type data and puts it in file
    	//temporary fix for unit count
    	//will implement unit tags later
    	if (IsCarryingVespene(*unit) == false) {
    		const sc2::ObservationInterface* obs = Observation();
    		const sc2::UnitTypes& unit_types = obs->GetUnitTypeData();
    		myfile << "A " <<  sc2::UnitTypeToName(unit->unit_type) << " was created on " << Observation()->GetGameLoop() << "\n";
    	}
    	


    	myfile.close();
    }
};

int main(int argc, char* argv[]) {
    Coordinator coordinator;
    coordinator.LoadSettings(argc, argv);

    Bot bot;
    coordinator.SetParticipants({
        CreateParticipant(Race::Terran, &bot),
        CreateComputer(Race::Zerg)
    });

    coordinator.LaunchStarcraft();
    coordinator.StartGame(sc2::kMapBelShirVestigeLE);

    while (coordinator.Update()) {
    }

    return 0;
}

